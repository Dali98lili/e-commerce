<?php
session_start();

$nom = $_POST['nom'];
$description = $_POST['description'];
$prix = $_POST['prix'];
$createur = $_POST['createur'];
$categorie = $_POST['categorie'];
$quantite = $_POST['quantite'];
$date_creation = date("Y-m-d");



// Upload image
$target_dir = "../../img/";
$target_file = $target_dir . basename($_FILES["image"]["name"]);

if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
    $image = $_FILES["image"]["name"];
} else {
    echo "Sorry, there was an error uploading your file.";
}

$date_creation = date('Y-m-d');
$date_modification = date('Y-m-d');

// Connection to the database
include "../../inc/functions.php";
$conn = connect();

// Use prepared statements to avoid SQL injection
$requette = $conn->prepare("INSERT INTO produits (nom, description, prix, image, categorie, createur, date_creation, date_modification) VALUES (?,?,?,?,?,?,?,?)");


$requette->bind_param("ssdsssss", $nom, $description, $prix, $image, $categorie, $createur, $date_creation, $date_modification);

// Execute the query
$resultat = $requette->execute();



if ($resultat) {
    $produit_id = $conn ->insert_id;

$requette2="INSERT INTO stock(produit,quantite,createur,date_creation) VALUES('$produit_id','$quantite','$createur','$date_creation')";
if($conn->query($requette2)){
    header('location:liste.php?ajout=ok');
}
   
} else {
    echo "Error d'ajouter le stock " . $requette->error;
}

// Close the prepared statement and database connection
$requette->close();
$conn->close();
?>
