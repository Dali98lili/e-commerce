
<nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="home"></span>
                  Acceuil <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="http://<?php echo $_SERVER['HTTP_HOST']; ?>/dashboard/project%20e-commerce/admin/categories/liste.php">
                  <span data-feather="file"></span>
                  Categories
                </a>
              <!-- l'erreur est là  : je veux acceder aux pages produits,categories,profile en changeant l'url mais ça ne fonctionne pas -->
              </li>
              <li class="nav-item">
                <a class="nav-link" href="http://<?php echo $_SERVER['HTTP_HOST']; ?>/dashboard/project%20e-commerce/admin/produits/liste.php">
                  <span data-feather="shopping-cart"></span>
                  Produits
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="http://<?php echo $_SERVER['HTTP_HOST']; ?>/dashboard/project%20e-commerce/admin/users/liste.php">
                  <span data-feather="users"></span>
                  Utilisateurs
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="#">
                  <span data-feather="bar-chart-2"></span>
                  Rapports
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="http://<?php echo $_SERVER['HTTP_HOST']; ?>/dashboard/project%20e-commerce/admin/stock/liste.php">
                  <span data-feather="bar-chart-2"></span>
                  stock
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="http://<?php echo $_SERVER['HTTP_HOST']; ?>/dashboard/project%20e-commerce/admin/profile.php">
                  <span data-feather="layers"></span>
                  Profile
                </a>
              </li>
            </ul>

            
          </div>
        </nav>