<?php
session_start();
//recuperation des donnes de la form
$nom = $_POST['nom'];
$description = $_POST['description'];
$createur = $_SESSION['id'];
$date_creation = date("Y-m-d"); 

//la chaine de connexion
include "../../inc/functions.php";
$conn = connect();
//creation de la requette 
$requette = "INSERT INTO categorie(nom,description,createur,date_creation) values('$nom','$description','$createur','$date_creation') ";
//execution
$resultat=$conn->query($requette);
if($resultat){
    header('location:liste.php?ajout=ok');
}


?>