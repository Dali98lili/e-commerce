<?php
session_start();
//recuperation des donnes de la form
$id=$_POST['idc'];
$nom = $_POST['nom'];
$description = $_POST['description'];
$date_modification = date("Y-m-d"); 

//la chaine de connexion
include "../../inc/functions.php";
$conn = connect();
//creation de la requette 
$requette = "UPDATE categorie SET nom='$nom',description='$description',date_modification='$date_modification' WHERE id='$id'  ";
//execution
$resultat=$conn->query($requette);
if($resultat){
    header('location:liste.php?modif=ok');
}


?>