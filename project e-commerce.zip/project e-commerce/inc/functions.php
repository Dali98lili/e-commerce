<?php 


function connect(){
  $servername="localhost";
  $DBuser = "root";
  $DBpassword ="";
  $DBname = "project e-commerce";
  
  $conn = mysqli_connect($servername, $DBuser, $DBpassword, $DBname);
  
  if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }
return $conn;
}
 function getAllCategories(){
    
   $conn= connect();
    //echo "Connected successfully";
    
    $requette = "SELECT * FROM categorie";
    $resultat = $conn->query($requette);
    $categorie=$resultat->fetch_all(MYSQLI_ASSOC);
    
    //var_dump($categorie);
    
    return $categorie;
    
   
 }

 function getAllProduct(){
  $conn= connect();
  
  $requette = "SELECT * FROM produits";
  $resultat = $conn->query($requette);
  $produits=$resultat->fetch_all(MYSQLI_ASSOC);
  
  
  return $produits;
 }

 function searchProduct($keyword){
  $conn= connect();
  //creation de la requete search
  $requette = "SELECT * FROM produits WHERE nom LIKE '%$keyword%' ";

  $resultat = $conn->query($requette);
  $produits=$resultat->fetch_all(MYSQLI_ASSOC);
  return $produits;
 }


 function getProduitById($id){
  $conn = connect();
  $requette = "SELECT * FROM produits WHERE id=$id";
  $resultat = $conn->query($requette);
  $produit=$resultat->fetch_assoc();
  return $produit;
 }  
 function addVisiteur($data) {
  $conn = connect();
  $mdphash = md5($data['mdp']);
  $requette = "INSERT INTO users (nom, prenom, email, telephone, mdp) VALUES ('" . $data['nom'] . "','" . $data['prenom'] . "','" . $data['email'] . "','" . $data['telephone'] . "','" . $mdphash . "')";

  $resultat = $conn->query($requette);

if($resultat ) {
  return true;
}else{
  return false;
}
 }

 function connectUser($data){
  $conn= connect();
  $email=$data['email'];
  $mdp=md5($data['mdp']);
  $requette="SELECT * FROM users WHERE email='$email' AND mdp='$mdp'";
  $resultat = $conn->query($requette);
  $user=$resultat->fetch_assoc();
  return $user;
 }

 function connectAdmin($data){
  $conn= connect();
  $email=$data['email'];
  $mdp=md5($data['mdp']);
  $requette="SELECT * FROM administrateur WHERE email='$email' AND mdp='$mdp'";
  $resultat = $conn->query($requette);
  $user=$resultat->fetch_assoc();
  return $user;
 }

 function GetAllUsers(){
  $conn= connect();
  $requette="SELECT * FROM users WHERE etat=0";
  $resultat = $conn->query($requette);
  $users=$resultat->fetch_all(MYSQLI_ASSOC);
  return $users;
 }
 function GetStock(){
  $conn=connect();
  $requette=" select s.id,p.nom,s.quantite from produits p,stock s where p.id = s.produit ";
  $resultat = $conn->query($requette);
  $stocks=$resultat->fetch_all(MYSQLI_ASSOC);
  return $stocks;
 
 }
  ?>