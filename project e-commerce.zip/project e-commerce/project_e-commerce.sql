-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 28 nov. 2023 à 19:43
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `project e-commerce`
--

-- --------------------------------------------------------

--
-- Structure de la table `administrateur`
--

CREATE TABLE `administrateur` (
  `id` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mdp` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `administrateur`
--

INSERT INTO `administrateur` (`id`, `nom`, `email`, `mdp`) VALUES
(1, 'admin', 'admin@ShopyFast.ca', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id` int(50) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `createur` varchar(50) NOT NULL,
  `date_creation` date NOT NULL,
  `date_modification` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id`, `nom`, `description`, `createur`, `date_creation`, `date_modification`) VALUES
(3, 'categorie 3', 'categorie 3', '', '0000-00-00', '0000-00-00'),
(12, 'tech', 'produit tech et gaming', '1', '2023-11-25', '2023-11-25');

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

CREATE TABLE `produits` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `prix` float NOT NULL,
  `image` varchar(255) NOT NULL,
  `categorie` int(11) NOT NULL,
  `createur` int(11) NOT NULL,
  `date_creation` date NOT NULL,
  `date_modification` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `produits`
--

INSERT INTO `produits` (`id`, `nom`, `description`, `prix`, `image`, `categorie`, `createur`, `date_creation`, `date_modification`) VALUES
(1, 'Lunettes Solaires', 'Lunettes Solaires: Alliance parfaite entre style et protection UV. Profitez du soleil avec élégance et tranquillité d\'esprit. Un accessoire incontournable pour des journées éclatantes.', 1500, 'lunette.jpg', 1, 0, '0000-00-00', '0000-00-00'),
(2, 'Sac de Golf Premium', 'Dominez le green avec notre Sac de Golf haut de gamme. Léger, stylé et fonctionnel, il offre l\'espace idéal pour vos clubs et accessoires essentiels. Libérez votre jeu avec élégance.', 750, 'golf.jpg', 3, 0, '0000-00-00', '0000-00-00'),
(3, 'Casque bluetooth', 'Découvrez le confort sans fil avec notre Casque Bluetooth premium. Son design élégant, sa qualité sonore exceptionnelle et sa connectivité facile en font le compagnon idéal pour une expérience musicale immersive. Libérez-vous des fils et plongez dans le son de la liberté.', 120, 'casque.jpg', 2, 0, '0000-00-00', '0000-00-00'),
(4, '', '', 0, '', 0, 0, '0000-00-00', '0000-00-00'),
(5, '', '', 0, '', 0, 0, '0000-00-00', '0000-00-00'),
(6, 'hama', '3abed mnayek lil bi3', 30, 'C:xampp	mpphpEE7D.tmp', 12, 1, '0000-00-00', '0000-00-00'),
(7, '', '', 0, '', 0, 0, '0000-00-00', '0000-00-00'),
(8, 'fawzi', '3abed mouch lil bi3', 1000, '', 12, 1, '0000-00-00', '0000-00-00'),
(9, '', '', 0, '', 0, 0, '2023-11-28', '2023-11-28'),
(10, 'zebi', 'mouch lil bi3 na3tihoulek blech', 30, 'Capture d\'écran 2023-09-18 234508.png', 2, 1, '2023-11-28', '2023-11-28'),
(11, 'hama chrab', 'fhjdbsiocjpq', 120, 'Capture d\'écran 2023-09-18 234515.png', 3, 1, '2023-11-28', '2023-11-28'),
(12, 'hama stock', 'stockkkkkk', 100, 'Capture d\'écran 2023-11-03 143844.png', 12, 1, '2023-11-28', '2023-11-28'),
(13, 'dalida', 'jdhvfbkln,mcs;', 20, 'Capture d\'écran 2023-09-18 234536.png', 3, 1, '2023-11-28', '2023-11-28'),
(14, 'zebi zebi', 'fvjhebknlds,cmqùx', 50000, 'Capture d\'écran 2023-09-15 161410.png', 12, 1, '2023-11-28', '2023-11-28'),
(15, 'dali', 'm;kjh,ngcd', 120, 'Capture d\'écran 2023-09-18 234454.png', 3, 1, '2023-11-28', '2023-11-28');

-- --------------------------------------------------------

--
-- Structure de la table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `produit` int(11) DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL,
  `createur` int(11) DEFAULT NULL,
  `date_creation` date DEFAULT NULL,
  `date_modification` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `stock`
--

INSERT INTO `stock` (`id`, `produit`, `quantite`, `createur`, `date_creation`, `date_modification`) VALUES
(1, 12, 22, 1, '0000-00-00', NULL),
(2, 13, 100000, 1, '0000-00-00', NULL),
(3, 14, 14, 1, '0000-00-00', NULL),
(4, 15, 52410, 1, '2023-11-28', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `id` int(50) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `etat` int(11) DEFAULT 0,
  `date_creation` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`nom`, `prenom`, `email`, `id`, `mdp`, `telephone`, `etat`, `date_creation`) VALUES
('dali', 'lili', 'dali.ellili97@gmail.com', 1, 'dali123', '5142424779', 0, '0000-00-00'),
('hama', 'chicha', 'hama@gmail.com', 3, '12345678', '1122336655', 0, '0000-00-00'),
('hama', 'chrab', 'test@test', 6, '145236', '696969', 0, '0000-00-00'),
('lili', 'dali', 'dalida@test', 7, '55555', '88888', 1, '0000-00-00'),
('hama', 'chicha', 'dali.ellili97@gmail.com', 8, '22222', '5142424779', 1, '0000-00-00'),
('dali', 'lili', 'dali.ellili98@gmail.com', 9, '12345678', '5142424779', 0, '0000-00-00'),
('dali', 'lili', 'dali@gmail.com', 10, '', '123556', 0, '0000-00-00'),
('testeur', 'test', 'test@test.com', 11, '', '555555', 0, '0000-00-00'),
('hama', 'abdallah', 'mohamed@hama', 12, '', '123246', 0, '0000-00-00'),
('hama', 'abdallah', 'mohamed@hama', 13, '', '123246', 0, '0000-00-00'),
('safwen', 'naimi', 'safwen.naimi@gmail.com', 14, '', '25555555', 0, '0000-00-00'),
('gg', 'jj', 'gg@gg', 15, '', '0123', 0, '0000-00-00'),
('dd', 'ff', 'dd@dd', 17, '', '55', 0, '0000-00-00'),
('sss', 'xxxxx', 'ss@ss', 19, '81dc9bdb52d04dc20036dbd8313ed055', '55555', 1, '0000-00-00'),
('hamza', 'hamza', 'hamza@gmail.com', 20, '202cb962ac59075b964b07152d234b70', '26552', 1, '0000-00-00');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `administrateur`
--
ALTER TABLE `administrateur`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `produits`
--
ALTER TABLE `produits`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `administrateur`
--
ALTER TABLE `administrateur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `produits`
--
ALTER TABLE `produits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
