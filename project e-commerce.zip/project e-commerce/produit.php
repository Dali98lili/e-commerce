<?php 
 include "inc/functions.php";
$categorie = getAllCategories();

if (isset($_GET['id'])){
  $produit = getProduitById($_GET['id']);
  $categories = getAllCategories(); 
}




 ?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ShopyFast</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  </head>
  <body>
    <!--navbar-->
  <?php 
  include "inc/header.php";
  ?>
<!--fin navbar-->
    
<div class="row col-12 mt-4" >

<div class="card col-8 offset-2" >
  <img src="img/<?php echo $produit['image'];?>" class="card-img-top" alt="...">
  <div class="card-body">
    <?php  
    // Traitement des données du produit
    echo "<h5 class='card-title'>" . $produit['nom'] . "</h5>";  ?>
    <p class="card-text"><?php echo  $produit['description']  ?></p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><?php echo $produit['prix'] ?> $</li>
    <?php
    foreach($categories as $index=> $categorie){
      if($categorie['id']== $produit['categorie']){
print '<button class="btn btn-success mb-2 " >'.$categorie['nom'].'</button>';
      }
    }
    ?>
    
   
  </ul>
  
</div>
  


<!--footer-->
<?php 
include "inc/footer.php";
?>
<!--fin footer-->



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>