<?php 
 session_start();
 include "inc/functions.php";
 //var_dump($_SESSION['panier']);
 $total =0;
 if(isset($_SESSION['panier'])){
  $total = $_SESSION['panier'][1];

 }

$categorie = getAllCategories();

if(!empty($_POST)){//BUTTON SEARCH

 $produits = searchProduct($_POST['search']);
}else{
$produits = getAllProduct();
}
$commandes=array(array());;
if(isset($_SESSION['panier'])){
    if (count($_SESSION['panier'][3]) > 0){
        $commandes=$_SESSION['panier'][3];
    }
}



 ?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ShopyFast</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  </head>
  <body>
    <!--navbar-->
  <?php 
  include "inc/header.php";
  ?>
<!--fin navbar-->
    
<div class="row col-12 mt-4 p-5" >

<h1>Panier</h1>
  
<table class="table">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Produit</th>
            <th scope="col">Quantité</th>
            <th scope="col">Total</th>
            <th scope="col">Actions</th>
        </tr>
    </thead>
    <tbody>
       <?php
       foreach ($commandes as $index => $commande) {
           print '<tr>
               <th scope="row">' . ($index + 1) . '</th>
               <td>' . (isset($commande[5]) ? $commande[5] : ' ') . '</td>
               <td>' . (isset($commande[0]) ? $commande[0] : ' ') . ' pièces</td>
               <td>' . (isset($commande[1]) ? $commande[1] : ' ') . ' $</td>
               <td> <a href="actions/enlever-produit-panier.php?id='.$index.'" class="btn btn-danger">Supprimer</a></td>
           </tr>';
       }
       ?>
    </tbody>
</table>
   <div class="text-end mt-3">
    <h3>Total :<?php echo $total.' $'; ?></h3>
    <hr/>
    <a href="actions/valider-panier.php"class="btn btn-success" style="width:100px">valider</a>
   </div>
            
            


<?php 
include "inc/footer.php";
?>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>