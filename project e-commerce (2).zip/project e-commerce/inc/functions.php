<?php 


function connect(){
  $servername="localhost";
  $DBuser = "root";
  $DBpassword ="";
  $DBname = "project e-commerce";
  
  $conn = mysqli_connect($servername, $DBuser, $DBpassword, $DBname);
  
  if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }
return $conn;
}
 function getAllCategories(){
    
   $conn= connect();
    //echo "Connected successfully";
    
    $requette = "SELECT * FROM categorie";
    $resultat = $conn->query($requette);
    $categorie=$resultat->fetch_all(MYSQLI_ASSOC);
    
    //var_dump($categorie);
    
    return $categorie;
    
   
 }

 function getAllProduct(){
  $conn= connect();
  
  $requette = "SELECT * FROM produits";
  $resultat = $conn->query($requette);
  $produits=$resultat->fetch_all(MYSQLI_ASSOC);
  
  
  return $produits;
 }

 function searchProduct($keyword){
  $conn= connect();
  //creation de la requete search
  $requette = "SELECT * FROM produits WHERE nom LIKE '%$keyword%' ";

  $resultat = $conn->query($requette);
  $produits=$resultat->fetch_all(MYSQLI_ASSOC);
  return $produits;

 }


 function getProduitById($id){
  $conn = connect();
  $requette = "SELECT * FROM produits WHERE id=$id";
  $resultat = $conn->query($requette);
  $produit=$resultat->fetch_assoc();
  return $produit;
 }  
 function addVisiteur($data) {
  $conn = connect();
  $mdphash = md5($data['mdp']);
  $requette = "INSERT INTO visiteurs (nom, prenom, email, telephone, mdp) VALUES ('" . $data['nom'] . "','" . $data['prenom'] . "','" . $data['email'] . "','" . $data['telephone'] . "','" . $mdphash . "')";

  $resultat = $conn->query($requette);

if($resultat ) {
  return true;
}else{
  return false;
}
 }

 function connectUser($data){
  $conn= connect();
  $email=$data['email'];
  $mdp=md5($data['mdp']);
  $requette="SELECT * FROM visiteurs WHERE email='$email' AND mdp='$mdp'";
  $resultat = $conn->query($requette);
  $user=$resultat->fetch_assoc();
  return $user;
 }

 function connectAdmin($data){
  $conn= connect();
  $email=$data['email'];
  $mdp=md5($data['mdp']);
  $requette="SELECT * FROM administrateur WHERE email='$email' AND mdp='$mdp'";
  $resultat = $conn->query($requette);
  $user=$resultat->fetch_assoc();
  return $user;
}


 function GetAllUsers(){
  $conn= connect();
  $requette="SELECT * FROM visiteurs WHERE etat=0";
  $resultat = $conn->query($requette);
  $users=$resultat->fetch_all(MYSQLI_ASSOC);
  return $users;
 }
 function GetStock(){
  $conn=connect();
  $requette=" select s.id,p.nom,s.quantite from produits p,stock s where p.id = s.produit ";
  $resultat = $conn->query($requette);
  $stocks=$resultat->fetch_all(MYSQLI_ASSOC);
  return $stocks;
 
 }

 function GetAllPaniers(){
  $conn=connect();
  $requette = " select v.nom , v.prenom , v.telephone ,p.total , p.etat , p.date_creation , p.id from panier p,visiteurs v WHERE p.visiteur = v.id ";
  $resultat = $conn->query($requette);
  $paniers=$resultat->fetch_all(MYSQLI_ASSOC);
  return $paniers;
 }
 function GetAllCommandes(){
  $conn=connect();
  $requette = " select p.nom,p.image ,c.quantite ,c.total ,c.panier from commandes c ,produits p where c.produit = p.id ";
  $resultat = $conn->query($requette);
  $commandes=$resultat->fetch_all(MYSQLI_ASSOC);
  return $commandes;
 }
 function  ChangerEtatPanier($data){
  $conn=connect();
  $requette = "UPDATE panier SET etat='".$data['etat']. "'WHERE id='".$data['panier_id']. "'";
  $resultat = $conn->query($requette);
 
 }
 function GetPaniersByEtat($paniers, $etat) {
  $paniersEtat = array();
  foreach ($paniers as $p) {
      if ($p['etat'] == $etat) {
          array_push($paniersEtat, $p);
      }
  }
  return $paniersEtat;
}
function EditAdmin($data){
  $conn=connect();
  if($data['mdp'] != ""){
    if($data['mdp'] != "")//mdp a une valeur
  $requette = "UPDATE administrateur SET nom='".$data['nom']. "' , email ='".$data['email']. "',mdp='".$data['mdp']. " ' WHERE id='".$data['id_admin']. "'";
  }else{
    $requette = "UPDATE administrateur SET nom='".$data['nom']. "' , email ='".$data['email']. "'";

  }
  $resultat = $conn->query($requette);
  return true;
}
function getGata(){

  $data= array();
  $conn=connect();

  //calculer le nombre des produits dans la bdd
  $requette = "SELECT COUNT(*) as totalProduits FROM produits";
  $resultat = $conn->query($requette);
  $nbrProduits = $resultat->fetch_assoc();

  //calculer le nombre des cat. dans la bdd
  $requette1 = "SELECT COUNT(*) as totalCategories FROM categorie";
  $resultat1 = $conn->query($requette1);
  $nbrCategories = $resultat1->fetch_assoc();

  //calculer le nombre des clients dans la bdd
  $requette2 = "SELECT COUNT(*) as totalClients FROM visiteurs";
  $resultat2 = $conn->query($requette2);
  $nbrClients = $resultat2->fetch_assoc();

  $data["produits"] = $nbrProduits['totalProduits'];
  $data["categories"] = $nbrCategories['totalCategories'];
  $data["clients"] = $nbrClients['totalClients'];

  return $data;
}


  ?>