<div class="bg-dark text-center p-5 mt-5">
<p class="text-white">
  Tous les droits reservès 2023 / Mohamed ali Ellili ; Mohamed Abdallah
</p>
</div>