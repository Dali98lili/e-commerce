-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 18 déc. 2023 à 01:29
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `project e-commerce`
--

-- --------------------------------------------------------

--
-- Structure de la table `administrateur`
--

CREATE TABLE `administrateur` (
  `id` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mdp` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `administrateur`
--

INSERT INTO `administrateur` (`id`, `nom`, `email`, `mdp`) VALUES
(1, 'admin', 'admin@shopyfast.ca', 'admin');

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id` int(50) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `createur` varchar(50) NOT NULL,
  `date_creation` date NOT NULL,
  `date_modification` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id`, `nom`, `description`, `createur`, `date_creation`, `date_modification`) VALUES
(3, 'categorie 3', 'categorie 3', '', '0000-00-00', '0000-00-00'),
(12, 'tech', 'produit tech et gaming', '1', '2023-11-25', '2023-11-25'),
(14, 'glkfdjhb', 'bhvgtcfrxds', '1', '2023-11-28', '0000-00-00');

-- --------------------------------------------------------

--
-- Structure de la table `commandes`
--

CREATE TABLE `commandes` (
  `id` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  `total` float NOT NULL,
  `panier` int(11) NOT NULL,
  `date_creation` date NOT NULL,
  `date_modification` date NOT NULL,
  `produit` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `commandes`
--

INSERT INTO `commandes` (`id`, `quantite`, `total`, `panier`, `date_creation`, `date_modification`, `produit`) VALUES
(63, 5, 3750, 42, '2023-12-01', '2023-12-01', 2),
(64, 2, 3000, 43, '2023-12-01', '2023-12-01', 1),
(65, 1, 1500, 44, '2023-12-01', '2023-12-01', 1),
(66, 2, 240, 45, '2023-12-01', '2023-12-01', 3),
(67, 6, 4500, 46, '2023-12-01', '2023-12-01', 2),
(68, 1, 750, 47, '2023-12-01', '2023-12-01', 2),
(69, 5, 3750, 48, '2023-12-01', '2023-12-01', 2),
(70, 2, 1500, 49, '2023-12-01', '2023-12-01', 2),
(71, 5, 7500, 49, '2023-12-01', '2023-12-01', 1);

-- --------------------------------------------------------

--
-- Structure de la table `panier`
--

CREATE TABLE `panier` (
  `id` int(11) NOT NULL,
  `visiteur` int(11) NOT NULL,
  `total` float NOT NULL,
  `etat` varchar(50) NOT NULL DEFAULT 'en cours',
  `date_creation` date NOT NULL,
  `date_modification` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `panier`
--

INSERT INTO `panier` (`id`, `visiteur`, `total`, `etat`, `date_creation`, `date_modification`) VALUES
(42, 20, 3750, 'En livraison', '2023-12-01', '0000-00-00'),
(43, 20, 3000, 'En livraison', '2023-12-01', '0000-00-00'),
(44, 21, 1500, 'En livraison', '2023-12-01', '0000-00-00'),
(45, 21, 240, 'En livraison', '2023-12-01', '0000-00-00'),
(46, 21, 4500, 'Livraison terminè', '2023-12-01', '0000-00-00'),
(47, 21, 750, 'en cours', '2023-12-01', '0000-00-00'),
(48, 21, 3750, 'en cours', '2023-12-01', '0000-00-00'),
(49, 22, 9000, 'En livraison', '2023-12-01', '0000-00-00');

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

CREATE TABLE `produits` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `prix` float NOT NULL,
  `image` varchar(255) NOT NULL,
  `categorie` int(11) NOT NULL,
  `createur` int(11) NOT NULL,
  `date_creation` date NOT NULL,
  `date_modification` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `produits`
--

INSERT INTO `produits` (`id`, `nom`, `description`, `prix`, `image`, `categorie`, `createur`, `date_creation`, `date_modification`) VALUES
(1, 'Lunettes Solaires', 'Lunettes Solaires: Alliance parfaite entre style et protection UV. Profitez du soleil avec élégance et tranquillité d\'esprit. Un accessoire incontournable pour des journées éclatantes.', 1500, 'lunette.jpg', 1, 0, '0000-00-00', '0000-00-00'),
(2, 'Sac de Golf Premium', 'Dominez le green avec notre Sac de Golf haut de gamme. Léger, stylé et fonctionnel, il offre l\'espace idéal pour vos clubs et accessoires essentiels. Libérez votre jeu avec élégance.', 750, 'golf.jpg', 3, 0, '0000-00-00', '0000-00-00'),
(3, 'Casque bluetooth', 'Découvrez le confort sans fil avec notre Casque Bluetooth premium. Son design élégant, sa qualité sonore exceptionnelle et sa connectivité facile en font le compagnon idéal pour une expérience musicale immersive. Libérez-vous des fils et plongez dans le son de la liberté.', 120, 'casque.jpg', 2, 0, '0000-00-00', '0000-00-00'),
(11, 'hama chrab', 'fhjdbsiocjpq', 120, 'Capture d\'écran 2023-09-18 234515.png', 3, 1, '2023-11-28', '2023-11-28'),
(12, 'hama stock', 'stockkkkkk', 100, 'Capture d\'écran 2023-11-03 143844.png', 12, 1, '2023-11-28', '2023-11-28'),
(15, 'dali', 'm;kjh,ngcd', 120, 'Capture d\'écran 2023-09-18 234454.png', 3, 1, '2023-11-28', '2023-11-28');

-- --------------------------------------------------------

--
-- Structure de la table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `produit` int(11) DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL,
  `createur` int(11) DEFAULT NULL,
  `date_creation` date DEFAULT NULL,
  `date_modification` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `stock`
--

INSERT INTO `stock` (`id`, `produit`, `quantite`, `createur`, `date_creation`, `date_modification`) VALUES
(1, 12, 22, 1, '0000-00-00', NULL),
(2, 13, 100000, 1, '0000-00-00', NULL),
(3, 14, 14, 1, '0000-00-00', NULL),
(4, 15, 52410, 1, '2023-11-28', NULL),
(5, 16, 5, 1, '2023-11-28', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `visiteurs`
--

CREATE TABLE `visiteurs` (
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `id` int(50) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `etat` int(11) DEFAULT 0,
  `date_creation` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `visiteurs`
--

INSERT INTO `visiteurs` (`nom`, `prenom`, `email`, `id`, `mdp`, `telephone`, `etat`, `date_creation`) VALUES
('hamza', 'hamza', 'hamza@gmail.com', 20, '202cb962ac59075b964b07152d234b70', '26552', 1, '0000-00-00'),
('dali', 'lili', 'dali@dali', 21, '202cb962ac59075b964b07152d234b70', '123456', 1, '0000-00-00'),
('safwen', 'naimi', 'safwen@safwen', 22, '202cb962ac59075b964b07152d234b70', '43855665', 1, '0000-00-00'),
('hama', 'abdallah', 'hama@hama', 23, '202cb962ac59075b964b07152d234b70', '55555', 0, '0000-00-00'),
('hama', 'chicha', 'dali.ellili97@gmail.com', 24, '202cb962ac59075b964b07152d234b70', '5142424779', 0, '0000-00-00'),
('dalida', 'lili', 'dalida@gmail', 25, '202cb962ac59075b964b07152d234b70', '55555', 0, '0000-00-00');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `administrateur`
--
ALTER TABLE `administrateur`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `commandes`
--
ALTER TABLE `commandes`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `panier`
--
ALTER TABLE `panier`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `produits`
--
ALTER TABLE `produits`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `visiteurs`
--
ALTER TABLE `visiteurs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `administrateur`
--
ALTER TABLE `administrateur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `commandes`
--
ALTER TABLE `commandes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT pour la table `panier`
--
ALTER TABLE `panier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT pour la table `produits`
--
ALTER TABLE `produits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT pour la table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `visiteurs`
--
ALTER TABLE `visiteurs`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
