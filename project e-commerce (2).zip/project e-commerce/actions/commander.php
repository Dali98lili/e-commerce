<?php
session_start();

// Test de la connexion utilisateur
if (!isset($_SESSION['nom'])) {
    header('location:../connexion.php');
    exit();
}

include "../inc/functions.php";

$conn = connect();


$visiteur = $_SESSION['id'];

// Variables POST
$id_produit = mysqli_real_escape_string($conn, $_POST['produit']);
$quantite = mysqli_real_escape_string($conn, $_POST['quantite']);

// Requête pour obtenir le prix du produit
$requete_prix = "SELECT prix,nom FROM produits WHERE id='$id_produit'";
$resultat_prix = $conn->query($requete_prix);
$produit = $resultat_prix->fetch_assoc();

$total = $quantite * $produit['prix'];
$date = date('Y-m-d');

if(!isset($_SESSION['panier'])){ //panier n'existe pas
    $_SESSION['panier'] = array($visiteur , 0 , $date, array()); // creation du panier
}
$_SESSION['panier'][1]+= $total ;
$_SESSION['panier'][3][]=array($quantite , $total , $date , $date , $id_produit , $produit['nom']);





header('location:../panier.php');
?>
