<?php
session_start();
include "../inc/functions.php";

// Vérifier si le panier a déjà été traité

    $conn = connect();

    //id visiteur
    $visiteur=$_SESSION['id'];
    $total=$_SESSION['panier'][1];
    $date= date('Y-m-d');

    // Création du panier
    $requette_panier = "INSERT INTO panier(visiteur,total,date_creation) VALUES('$visiteur','$total','$date')";
    $resultat_panier = $conn->query($requette_panier);
    $panier_id = $conn->insert_id;

    $commandes = $_SESSION['panier'][3];
    foreach ($commandes as $commande) {
        // Ajout de la commande
        $quantite = $commande[0];
        $total_commande = $commande[1];
        $id_produit = $commande[4];
        echo "Quantité: $quantite, Total Commande: $total_commande, ID Produit: $id_produit<br>";

        $requette = "INSERT INTO commandes(quantite,total,panier,date_creation,date_modification,produit) VALUES(
                      '$quantite','$total_commande','$panier_id','$date','$date','$id_produit')";
        $resultat = $conn->query($requette);
    }

    
    


// Ne pas supprimer le panier immédiatement après la première commande
 $_SESSION['panier'] = null;

// Redirection
header('location:../index.php');
?>
