<?php
session_start();

// Récupération des données du formulaire
$id = $_POST['idc'];
$nom = $_POST['nom'];
$description = $_POST['description'];
$date_modification = date("Y-m-d"); 

// La chaîne de connexion
include "../../inc/functions.php";
$conn = connect();

// Création de la requête 
$requette = "UPDATE categorie SET nom='$nom', description='$description', date_modification='$date_modification' WHERE id='$id'";

// Exécution
$resultat = $conn->query($requette);

// Vérification de la réussite de la requête
if ($resultat) {
    header('location:liste.php?modif=ok');
} else {
    
    echo "Erreur : " . $conn->error;
 
}

$conn->close();


?>