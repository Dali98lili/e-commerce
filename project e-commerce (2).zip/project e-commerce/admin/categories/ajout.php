<?php
session_start();

$nom = $_POST['nom'];
$description = $_POST['description'];
$createur = $_SESSION['id'];
$date_creation = date("Y-m-d"); 

include "../../inc/functions.php";
$conn = connect();

$requete = $conn->prepare("INSERT INTO categorie(nom, description, createur, date_creation) VALUES(?, ?, ?, ?)");

$requete->bind_param("ssis", $nom, $description, $createur, $date_creation);
$resultat = $requete->execute();


if ($resultat) {
    header('location:liste.php?ajout=ok');
} else {
    
    echo "Erreur lors de l'ajout : " . $requete->error;

}


$requete->close();
$conn->close();
?>
