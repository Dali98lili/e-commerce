<?php
//getter le id
$idc = $_GET['idcategorie'];
include "../../inc/functions.php";
$conn = connect();
$requette = "DELETE FROM categorie where id ='$idc'";
$resultat = $conn->query($requette);

if($resultat){

    echo"categorie supprimè avec succès";
   header('location:liste.php?delete=ok');
};


?>