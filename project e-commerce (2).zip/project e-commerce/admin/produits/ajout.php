<?php 
session_start();

if (isset($_POST['createur'])) {
    $createur = $_POST['createur'];
} else {
    echo "Erreur : Le champ 'createur' n'est pas défini dans le formulaire.";
    exit;
}

$nom = $_POST['nom'];
$description = $_POST['description'];
$prix = $_POST['prix'];
$categorie = $_POST['categorie'];
$quantite = $_POST['quantite'];
$date_creation = date("Y-m-d");

$target_dir = "../../img/";
$target_file = $target_dir . basename($_FILES["image"]["name"]);

if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
    $image = $_FILES["image"]["name"];
} else {
    echo "Désolé, une erreur s'est produite lors du téléchargement de votre fichier.";
}

include "../../inc/functions.php";
$conn = connect();

$requete = $conn->prepare("INSERT INTO produits(nom, description, prix, image, createur, categorie, date_creation) VALUES (?, ?, ?, ?, ?, ?, ?)");

$requete->bind_param("ssdssss", $nom, $description, $prix, $image, $createur, $categorie, $date_creation);
$resultat = $requete->execute();

if ($resultat) {
    $produit_id = $conn->insert_id;

    $requete2 = $conn->prepare("INSERT INTO stock(produit, quantite, createur, date_creation) VALUES (?, ?, ?, ?)");
    $requete2->bind_param("isss", $produit_id, $quantite, $createur, $date_creation);

    if ($requete2->execute()) {
        header('location:liste.php?ajout=ok');
    } else {
        echo "Erreur lors de l'ajout dans la table stock : " . $requete2->error;
    }
} 

$requete->close();
$requete2->close();
$conn->close();
?>
