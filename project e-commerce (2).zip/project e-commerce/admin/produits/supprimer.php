<?php
// Getter l'ID
$idp = $_GET['idp'];
include "../../inc/functions.php";
$conn = connect();
$requete = "DELETE FROM produits WHERE id ='$idp'";
$resultat = $conn->query($requete);

if ($resultat) {
    // Redirection après l'affichage du message
    header('location:liste.php?delete=ok');
    // Affichage du message
    echo "Produit supprimé avec succès";
} else {
    // En cas d'erreur, afficher un message ou rediriger vers une page d'erreur
    echo "Erreur lors de la suppression du produit : " . $conn->error;
    // ou
    // header('location:erreur.php');m
}
?>
