<?php
session_start();
//recuperation des donnes de la form
$id=$_POST['idp'];
$description = $_POST['description'];

//la chaine de connexion
include "../../inc/functions.php";
$conn = connect();
//creation de la requette 
$requette = "UPDATE produits SET description='$description' WHERE id='$id'  ";
//execution
$resultat=$conn->query($requette);
if($resultat){
    header('location:liste.php?modif=ok');
}


?>