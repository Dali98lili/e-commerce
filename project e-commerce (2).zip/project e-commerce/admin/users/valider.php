<?php
$idUser = $_GET['id'];
include "../../inc/functions.php";
$conn = connect();
$requette = "UPDATE visiteurs SET etat = 1 WHERE id='$idUser'";
$result= $conn->query($requette);

if($result){
    header('location:liste.php?valider=ok');
}else{
    echo"erreur de validation";
}
?>