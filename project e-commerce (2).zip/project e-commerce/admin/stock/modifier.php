<?php
session_start();
//recuperation des donnes de la form
$id=$_POST['idstock'];
$quantite = $_POST['quantite'];

//la chaine de connexion
include "../../inc/functions.php";
$conn = connect();
//creation de la requette 
$requette = "UPDATE stock SET quantite='$quantite' WHERE id='$id'  ";
//execution
$resultat=$conn->query($requette);
if($resultat){
    header('location:liste.php?modif=ok');
}


?>